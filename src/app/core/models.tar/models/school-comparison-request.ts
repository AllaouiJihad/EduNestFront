export interface SchoolComparisonRequest {
  schoolIds: number[];
}
