export interface Review {
  id: number;
  content: string;
  rating: number;
  createdAt: string;
  memberName: string;
}
