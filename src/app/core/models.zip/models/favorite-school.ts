export interface FavoriteSchool {
  id: number;
  schoolId: number;
  schoolName: string;
  schoolCity: string;
  categoryName: string;
  notes: string;
  addedDate: string;
  reviewCount: number;
}
