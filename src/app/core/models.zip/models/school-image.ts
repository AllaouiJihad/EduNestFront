export interface SchoolImage {
  id: number;
  url: string;
  caption: string;
}
